import streamlit as st
import pandas as pd
import joblib
st.title("Heart Disease Prediction System ❤")

with st.expander("About the system"):
    st.write("""
    
    This is a system built by students of babcock university which uses machine learning
    to predict the occurence of heart disease in patients.

    
    """) 



# Input fields
age = st.number_input("Age", min_value=1, max_value=120, value=30)

sex = st.radio("Sex", ["Male", "Female"])
sex_encoded = 1 if sex == "Male" else 0  # Assuming Male = 1, Female = 0

chest_pain_type = st.selectbox(
    "Chest Pain Type",
    ["Typical Angina", "Atypical Angina", "Non-Anginal Pain", "Asymptomatic"]
)
chest_pain_encoded = {"Typical Angina": 0, "Atypical Angina": 1, "Non-Anginal Pain": 2, "Asymptomatic": 3}[chest_pain_type]

resting_bp = st.number_input("Resting Blood Pressure (mm Hg)", min_value=50, max_value=200, value=120)

cholesterol = st.number_input("Cholesterol Level (mg/dL)", min_value=100, max_value=400, value=200)

fasting_bs = st.radio("Fasting Blood Sugar > 120 mg/dL", ["No", "Yes"])
fasting_bs_encoded = 1 if fasting_bs == "Yes" else 0  # Assuming Yes = 1, No = 0

resting_ecg = st.selectbox(
    "Resting ECG",
    ["Normal", "ST-T Wave Abnormality", "Left Ventricular Hypertrophy"]
)
resting_ecg_encoded = {"Normal": 0, "ST-T Wave Abnormality": 1, "Left Ventricular Hypertrophy": 2}[resting_ecg]

max_hr = st.number_input("Maximum Heart Rate Achieved", min_value=60, max_value=220, value=150)

exercise_angina = st.radio("Exercise-Induced Angina", ["No", "Yes"])
exercise_angina_encoded = 1 if exercise_angina == "Yes" else 0  #Yes = 1, No = 0

oldpeak = st.number_input("Oldpeak (ST Depression Induced by Exercise)", min_value=0.0, max_value=6.0, value=0.0, step=0.1)

st_slope = st.selectbox(
    "ST Slope",
    ["Upsloping", "Flat", "Downsloping"]
)
st_slope_encoded = {"Upsloping": 0, "Flat": 1, "Downsloping": 2}[st_slope]

num_major_vessels = st.slider("Number of Major Vessels (0-3) colored by fluoroscopy during imaging tests.", min_value=0, max_value=3, value=1)

thal = st.selectbox(
    "Thalassemia",
    ["Normal", "Fixed Defect", "Reversible Defect"]
)
thal_encoded = {"Normal": 1, "Fixed Defect": 2, "Reversible Defect": 3}[thal]




# Input Data

# Ensure the column names match the training data
input_data = pd.DataFrame([[age, sex_encoded, chest_pain_encoded, resting_bp, cholesterol, fasting_bs_encoded, 
                            resting_ecg_encoded, max_hr, exercise_angina_encoded, oldpeak, st_slope_encoded, 
                            num_major_vessels, thal_encoded]], 
                          columns=["Age", "Sex", "CheastPainType", 
                                   "RestingBP", "Cholesterol", "FastingBS", 
                                   "RestingECG", "MaxHR", "ExerciseAngina", 
                                   "Oldpeak", "ST_Slope", "NumMajorVessels", 
                                   "Thal"])




# Loading and using the model 


model = joblib.load("random_forest_model.pkl")

if st.button("Predict"):
    prediction = model.predict(input_data)


    if prediction[0] == 1:
        st.error("High risk of heart disease! ⚠️")
    else:
        st.success("Low risk of heart disease. ✅")


